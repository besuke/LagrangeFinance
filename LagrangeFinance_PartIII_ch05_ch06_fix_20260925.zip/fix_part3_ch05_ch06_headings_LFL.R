# fix_part3_ch05_ch06_headings_LFL.R
# Follow-up fix for Part III chapters 5 and 6.
#
# IMPORTANT:
# - Does not delete prose, equations, R code, figures, tables, or summary prose.
# - Only changes Markdown heading text/levels.
# - Safe to run AFTER the previous Part III heading revision script.

root <- getwd()
dir3 <- file.path(root, "part3_enterprise_riemann")

f5 <- file.path(dir3, "ch05_option_greeks_autodiff.qmd")
f6 <- file.path(dir3, "ch06_interest_rate_risk_autodiff.qmd")

stopifnot(file.exists(f5), file.exists(f6))

replace_one <- function(x, pattern, replacement) {
  idx <- grep(pattern, x, perl = TRUE)
  if (length(idx) != 1L) {
    stop(sprintf("Expected exactly one match for [%s], found %d", pattern, length(idx)))
  }
  x[idx] <- replacement
  x
}

# ============================================================
# Chapter 5
# Final top-level structure:
# III-5.1 オプション評価とリスク感応度
# III-5.2 ブラック・ショールズ式による解析解
# III-5.3 モンテカルロ法における自動微分のリスク感応度
# III-5.4 微分不可なオプションペイオフのケーススタディ
# ============================================================

x <- readLines(f5, encoding = "UTF-8", warn = FALSE)

# Ensure agreed four top-level headings.
x <- sub("^## III-5\\.1 .*$",
         "## III-5.1 オプション評価とリスク感応度", x)
x <- sub("^## III-5\\.2 .*$",
         "## III-5.2 ブラック・ショールズ式による解析解", x)
x <- sub("^## III-5\\.3 .*$",
         "## III-5.3 モンテカルロ法における自動微分のリスク感応度", x)
x <- sub("^## III-5\\.4 .*$",
         "### III-5.3.5 自動微分による一次感応度", x)
x <- sub("^## III-5\\.5 .*$",
         "## III-5.4 微分不可なオプションペイオフのケーススタディ", x)
x <- sub("^### III-5\\.5\\.1 (.*)$", "### III-5.4.1 \\1", x)
x <- sub("^### III-5\\.5\\.2 (.*)$", "### III-5.4.2 \\1", x)
x <- sub("^## III-5\\.6 (.*)$", "### III-5.4.3 \\1", x)

# Late old top-level sections are retained as subsections, including summary prose.
x <- sub("^## III-5\\.12 (.*)$", "### III-5.4.4 \\1", x)
x <- sub("^## III-5\\.13 (.*)$", "### III-5.4.5 \\1", x)
x <- sub("^## III-5\\.14 (.*)$", "### III-5.4.6 \\1", x)
x <- sub("^## III-5\\.15 (.*)$", "### III-5.4.7 \\1", x)

writeLines(x, f5, useBytes = TRUE)

# ============================================================
# Chapter 6
# Final top-level structure:
# III-6.1 金利スワップ評価とリスク感応度
# III-6.2 金利リスクにおける自動微分
# III-6.3 イールドカーブと自動微分
# III-6.4 バケットDV01とGPS
# ============================================================

x <- readLines(f6, encoding = "UTF-8", warn = FALSE)

x <- sub("^## III-6\\.1 .*$",
         "## III-6.1 金利スワップ評価とリスク感応度", x)

# Existing 6.2-6.5 form the single-rate AD implementation/validation flow.
x <- sub("^## III-6\\.2 .*$",
         "## III-6.2 金利リスクにおける自動微分", x)
x <- sub("^## III-6\\.3 (.*)$",
         "### III-6.2.1 \\1", x)
x <- sub("^## III-6\\.4 (.*)$",
         "### III-6.2.2 \\1", x)
x <- sub("^## III-6\\.5 (.*)$",
         "### III-6.2.3 \\1", x)

# Curve-vector extension.
x <- sub("^## III-6\\.6 .*$",
         "## III-6.3 イールドカーブと自動微分", x)
x <- sub("^### III-6\\.6\\.1 (.*)$",
         "### III-6.3.1 \\1", x)

# Bucketed DV01 / GPS becomes the fourth top-level section.
x <- sub("^## III-6\\.11 .*$",
         "## III-6.4 バケットDV01とGPS", x)

# Preserve all remaining content as subsections of 6.4.
x <- sub("^## III-6\\.12 (.*)$", "### III-6.4.1 \\1", x)
x <- sub("^## III-6\\.13 (.*)$", "### III-6.4.2 \\1", x)
x <- sub("^## III-6\\.14 (.*)$", "### III-6.4.3 \\1", x)
x <- sub("^## III-6\\.15 (.*)$", "### III-6.4.4 \\1", x)
x <- sub("^## III-6\\.16 (.*)$", "### III-6.4.5 \\1", x)

writeLines(x, f6, useBytes = TRUE)

# Audit: fail if unexpected top-level headings remain.
expected5 <- c(
  "## III-5.1 オプション評価とリスク感応度",
  "## III-5.2 ブラック・ショールズ式による解析解",
  "## III-5.3 モンテカルロ法における自動微分のリスク感応度",
  "## III-5.4 微分不可なオプションペイオフのケーススタディ"
)
expected6 <- c(
  "## III-6.1 金利スワップ評価とリスク感応度",
  "## III-6.2 金利リスクにおける自動微分",
  "## III-6.3 イールドカーブと自動微分",
  "## III-6.4 バケットDV01とGPS"
)

audit <- function(path, expected) {
  y <- readLines(path, encoding = "UTF-8", warn = FALSE)
  actual <- grep("^## III-", y, value = TRUE)
  if (!identical(actual, expected)) {
    stop(
      "Unexpected top-level headings in ", basename(path), ":\n",
      paste(actual, collapse = "\n")
    )
  }
  cat("\n", basename(path), "\n", sep = "")
  cat(paste0("  ", actual, collapse = "\n"), "\n")
}

audit(f5, expected5)
audit(f6, expected6)

cat("\nChapter 5 and Chapter 6 heading fix completed.\n")
cat("No prose, equations, code, figures, tables, or summary prose were intentionally deleted.\n")
