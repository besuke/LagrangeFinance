﻿#requires -Version 5.1
[CmdletBinding()]param()
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
if ([Environment]::OSVersion.Platform -ne 'Win32NT') { throw 'Windows専用です。' }
if ([Threading.Thread]::CurrentThread.ApartmentState -ne 'STA') { throw 'powershell.exe -STA -File .\Start-Curie.ps1 を使用してください。' }
Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase
$root=$PSScriptRoot
[void][IO.Directory]::CreateDirectory((Join-Path $root 'output'))
[xml]$xml=Get-Content (Join-Path $root 'MainWindow.xaml') -Raw -Encoding UTF8
$window=[Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader $xml))
$ui=@{}
foreach($node in $xml.SelectNodes('//*')) { $n=$node.GetAttribute('Name','http://schemas.microsoft.com/winfx/2006/xaml'); if($n){$ui[$n]=$window.FindName($n)} }
$script:db=@{}; $script:cases=@(); $script:candidates=@(); $script:broker=@(); $script:compliance=@(); $script:diff=@()
$ranks=@('AAA','AA+','AA','AA-','A+','A','A-','BBB+','BBB','BBB-','BB+','BB','BB-','B+','B','B-','CCC','CC','C','D')
$schemas=[ordered]@{
funds='fund_id name currencies min_years max_years min_rating min_spread_bp max_order_amount'
offers='offer_id fund_id isin issuer_id issuer currency years rating spread_bp price broker offer_date'
reports='report_id issuer_id broker published_date title link'
market='market_date currency instrument tenor mid unit source'
orders='order_id fund_id isin broker order_date side quantity status'
trades='trade_id order_id fund_id isin broker trade_date side quantity price currency'
valuations='valuation_date fund_id isin provider market_value base_currency'
performance='fund_id period_start period_end provider base_currency opening_nav closing_nav net_flow twr_pct benchmark_pct'
incidents='incident_id occurred_date fund_id category severity status summary improvement teams_link'
}
function Num($s){$v=0.0;if(-not [double]::TryParse([string]$s,[Globalization.NumberStyles]::Float,[Globalization.CultureInfo]::InvariantCulture,[ref]$v) -or [double]::IsNaN($v) -or [double]::IsInfinity($v)){throw "不正な数値: $s"};return $v}
function Day($s){return [datetime]::ParseExact([string]$s,'yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture)}
function Guard([scriptblock]$s){try{& $s}catch{$ui.Status.Text=$_.Exception.Message;[void][Windows.MessageBox]::Show($_.Exception.Message,'CURIE','OK','Warning')}}
function ReadData($key,$path){
 $rows=@(Import-Csv -LiteralPath $path -Encoding UTF8)
 if(-not $rows.Count){throw 'CSVは1行以上必要です。'}
 foreach($n in $schemas[$key].Split(' ')){if($n -notin $rows[0].PSObject.Properties.Name){throw "必須列なし: $n"}}
 $numeric=@('min_years','max_years','min_spread_bp','max_order_amount','years','spread_bp','price','quantity','market_value','opening_nav','closing_nav','net_flow','twr_pct','benchmark_pct','mid')
 foreach($r in $rows){foreach($prop in $r.PSObject.Properties){if($prop.Name -in $numeric){[void](Num $prop.Value)};if($prop.Name -match '(_date|period_start|period_end)$'){[void](Day $prop.Value)}}
  if($key -eq 'funds'){if((Num $r.min_years) -lt 0 -or (Num $r.max_years) -lt (Num $r.min_years) -or (Num $r.max_order_amount) -le 0 -or $r.min_rating -notin $ranks){throw 'ファンド条件が不正です。'}}
  if($key -eq 'valuations' -and $r.provider -notin @('DIR','ICE','QUANT')){throw '評価会社はDIR / ICE / QUANTです。'}
  if($key -eq 'trades' -and ((Num $r.quantity) -le 0 -or (Num $r.price) -le 0)){throw '約定数量・価格は正数です。'}
 }
 $id= switch($key){funds{'fund_id'} offers{'offer_id'} reports{'report_id'} orders{'order_id'} trades{'trade_id'} incidents{'incident_id'} default{$null}}
 if($id -and @($rows | Group-Object $id | Where-Object Count -gt 1).Count){throw "ID重複: $id"}
 return $rows
}
function Bind($name,$data){$ui[$name].ItemsSource=@($data)}
function SaveDialog($filter,$name){$d=New-Object Microsoft.Win32.SaveFileDialog;$d.Filter=$filter;$d.FileName=$name;if($d.ShowDialog($window)){return $d.FileName}}
function GetRules {
 $f=$ui.Fund.SelectedItem;if($null -eq $f){throw 'ファンドを選択してください。'}
 $lo=Num $ui.MinY.Text;$hi=Num $ui.MaxY.Text;$sp=Num $ui.Spread.Text;$lim=Num $ui.Limit.Text
 $cc=@($ui.Currencies.Text.Split(';') | ForEach-Object {$_.Trim().ToUpperInvariant()} | Where-Object {$_})
 if($lo -lt 0 -or $hi -lt $lo -or $lim -le 0 -or -not $cc.Count -or @($cc|Where-Object {$_ -notmatch '^[A-Z]{3}$'}).Count -or $ui.Rating.SelectedItem -notin $ranks){throw '投資条件を確認してください。'}
 return [pscustomobject]@{fund_id=$f.fund_id; currencies=$cc; min=$lo; max=$hi; rating=[array]::IndexOf($ranks,$ui.Rating.SelectedItem); spread=$sp; limit=$lim}
}
function Violations($o,$r){
 $v=@();if($o.currency -notin $r.currencies){$v+='通貨'}
 if((Num $o.years) -lt $r.min -or (Num $o.years) -gt $r.max){$v+='年限'}
 $rank=[array]::IndexOf($ranks,$o.rating);if($rank -lt 0 -or $rank -gt $r.rating){$v+='格付け'}
 if((Num $o.spread_bp) -lt $r.spread){$v+='スプレッド'}
 return $v
}

$script:results=@{};$script:active=$null;$script:fingerprint='';$script:strategies=@{}
$moduleNames=@{Overview='オファーシート・レポート概況';Proposal='オファー銘柄＋発注提案';Pricing='債券時価検証';Execution='発注および約定分析';Sellside='証券セルサイド評価';MIS='MIS＋業務改善計画'}
$window.Icon=New-Object Windows.Media.Imaging.BitmapImage ([uri](Join-Path $root 'assets/curie.ico'))
$ui.BrandIcon.Source=New-Object Windows.Media.Imaging.BitmapImage ([uri](Join-Path $root 'assets/curie.png'))
function Fingerprint {
 $parts=@(foreach($k in $schemas.Keys){$path=Join-Path $root "data/$k.csv";if(Test-Path $path){$f=Get-Item $path;"$k|$($f.Length)|$($f.LastWriteTimeUtc.Ticks)"}else{"$k|missing"}})
 return ($parts -join ';')
}
function Monitor {
 $display=@{funds='ファンド戦略';offers='オファーシート';reports='格付け・各種レポート索引';market='マーケット';orders='発注';trades='約定';valuations='ICE / DIR / 当社時価';performance='ファンドパフォーマンス';incidents='Teams障害・業務改善'}
 $rows=@(foreach($k in $schemas.Keys){$path=Join-Path $root "data/$k.csv";if(Test-Path $path){
 try{$f=Get-Item $path;$r=@(Import-Csv -LiteralPath $path -Encoding UTF8);$dateCol=@('offer_date','published_date','market_date','order_date','trade_date','valuation_date','period_end','occurred_date')|Where-Object { $r.Count -and $_ -in $r[0].PSObject.Properties.Name }|Select-Object -First 1
 $target='—';if($dateCol){$dates=@($r|ForEach-Object {$_.$dateCol}|Sort-Object);if($dates.Count){$target="$($dates[0]) ～ $($dates[-1])"}}
 [pscustomobject]@{データ=$display[$k];ファイル="$k.csv";最終更新=$f.LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss');容量KB=[math]::Round($f.Length/1KB,1);レコード数=$r.Count;対象日=$target;状態='配置済み'}
 }catch{[pscustomobject]@{データ=$display[$k];ファイル="$k.csv";最終更新='—';容量KB='—';レコード数='—';対象日='—';状態='読取中／確認待ち'}}
 }else{[pscustomobject]@{データ=$display[$k];ファイル="$k.csv";最終更新='—';容量KB=0;レコード数=0;対象日='—';状態='未到着'}}})
 Bind ArrivalGrid $rows
 $fp=Fingerprint
 if($script:fingerprint -and $fp -ne $script:fingerprint){
 foreach($key in @($script:results.Keys)){if($script:results[$key].fingerprint -ne $fp){$ui["Meta$key"].Text='データ更新あり・再実行してください ／ '+$script:results[$key].meta;$ui["Result$key"].Foreground=[Windows.Media.Brushes]::DarkGoldenrod}}
 }
 $script:fingerprint=$fp
}
function LoadFund {
 $f=$ui.Fund.SelectedItem;if($null -eq $f){return}
 $ui.Currencies.Text=$f.currencies;$ui.MinY.Text=$f.min_years;$ui.MaxY.Text=$f.max_years;$ui.Rating.SelectedItem=$f.min_rating;$ui.Spread.Text=$f.min_spread_bp;$ui.Limit.Text=$f.max_order_amount
 $ui.Purpose.Text='信用力とスプレッドのバランスを取り、許容範囲内で運用する。';$ui.FXLimit.Text='100';$ui.VaRLimit.Text=''
 if($script:strategies.ContainsKey($f.fund_id)){$s=$script:strategies[$f.fund_id];$ui.Purpose.Text=$s.purpose;$ui.FXLimit.Text=$s.fx_limit_pct;$ui.VaRLimit.Text=$s.credit_var_limit_pct}
}
function LoadAll {
 $tmp=@{};foreach($k in $schemas.Keys){$tmp[$k]=@(ReadData $k (Join-Path $root "data/$k.csv"))};$script:db=$tmp
}
function Context {
 if($null -eq $ui.From.SelectedDate -or $null -eq $ui.To.SelectedDate){throw '期間を選んでください。'}
 $f=$ui.AnalysisFund.SelectedItem;if($null -eq $f){throw 'ファンドを選んでください。'}
 $lo=$ui.From.SelectedDate.Date;$hi=$ui.To.SelectedDate.Date;if($lo -gt $hi){throw '期間が逆です。'}
 $threshold=Num $ui.Threshold.Text;if($threshold -lt 0){throw '乖離閾値は0以上です。'}
 return [pscustomobject]@{fund_id=$f.fund_id;name=$f.name;lo=$lo;hi=$hi;threshold=$threshold}
}
function InPeriod($s,$c){$dt=Day $s;return ($dt -ge $c.lo -and $dt -le $c.hi)}
function Encode($s){return [System.Net.WebUtility]::HtmlEncode([string]$s)}
function RenderReport($key,$rows,$summary,$meta){
 $file=Join-Path $root ("output/{0}_{1}.html" -f $key,[datetime]::Now.ToString('yyyyMMdd_HHmmss_fff'))
 $table=if(@($rows).Count){@($rows)|ConvertTo-Html -Fragment|Out-String}else{'<p>該当データはありません（実行済み・0件）。</p>'}
 $html='<!doctype html><html lang="ja"><meta charset="utf-8"><title>CURIE</title><style>body{font-family:Meiryo,sans-serif;margin:36px;color:#183344}h1{border-bottom:3px solid #1b8583;padding-bottom:15px}table{border-collapse:collapse;font-size:12px}td,th{padding:9px;border:1px solid #d3e1e6}th{background:#eaf5f5}</style><h1>CURIE / '+(Encode $moduleNames[$key])+'</h1><p>'+(Encode $meta)+'</p><h2>'+(Encode $summary)+'</h2><p>プロトタイプ。全同梱データは架空です。</p>'+$table+'</html>'
 $html|Set-Content -LiteralPath $file -Encoding UTF8;return $file
}
function ShowResult($key){
 if(-not $script:results.ContainsKey($key)){return}
 $script:active=$key;$r=$script:results[$key];Bind DetailGrid $r.rows
 $ui.DetailTitle.Text=$moduleNames[$key];$ui.OpenOutput.IsEnabled=$true;$ui.PrintPdf.IsEnabled=$true;$ui.CreateCase.IsEnabled=($key -eq 'Proposal')
}
function RunAnalysis($key){
 $ui["Run$key"].IsEnabled=$false;$ui["Result$key"].Text='実行中…';$ui["View$key"].IsEnabled=$false
 try{
 LoadAll;$c=Context;$rows=@();$summary='';$notes=''
 $offers=@($script:db.offers|Where-Object {$_.fund_id -eq $c.fund_id -and (InPeriod $_.offer_date $c)})
 $ids=@($script:db.offers|Where-Object fund_id -eq $c.fund_id|ForEach-Object issuer_id|Select-Object -Unique)
 $reports=@($script:db.reports|Where-Object {$_.issuer_id -in $ids -and (InPeriod $_.published_date $c)})
 switch($key){
 'Overview'{
 $new=@($offers|Where-Object {$o=$_;-not @($script:db.offers|Where-Object {$_.fund_id -eq $o.fund_id -and $_.isin -eq $o.isin -and (Day $_.offer_date) -lt $c.lo}).Count}|Sort-Object isin -Unique)
 $rows=@(foreach($o in $new){[pscustomobject]@{日付=$o.offer_date;区分='新規オファー';銘柄=$o.issuer;概要="$($o.currency) / 残存$($o.years)年 / 格付$($o.rating) / spread $($o.spread_bp)bp";参照=$o.isin}}
 foreach($r in $reports){[pscustomobject]@{日付=$r.published_date;区分='レポート';銘柄=$r.issuer_id;概要=$r.title;参照=$r.link}})
 $summary="新規銘柄 $($new.Count) 件 ／ レポート $($reports.Count) 件"
 $notes='新規はファンド別の既存オファー履歴と比較。レポートは対象発行体の索引概要で、本文自動要約は未接続。'
 }
 'Proposal'{
 $f=@($script:db.funds|Where-Object fund_id -eq $c.fund_id);if($f.Count -ne 1){throw 'ファンド戦略を解決できません。'};$f=$f[0]
 $rule=[pscustomobject]@{currencies=$f.currencies.Split(';');min=(Num $f.min_years);max=(Num $f.max_years);rating=[array]::IndexOf($ranks,$f.min_rating);spread=(Num $f.min_spread_bp)}
 $rows=@(foreach($o in $offers){$v=@(Violations $o $rule);if(-not $v.Count){$o|Select-Object *,@{n='確認';e={'戦略条件適合・保有照合未接続'}}}})
 $cases=@($script:cases|Where-Object {$_.fund_id -eq $c.fund_id -and (InPeriod ([datetime]$_.created_at).ToString('yyyy-MM-dd') $c)})
 $summary="条件適合候補 $($rows.Count) 件 ／ 発注案件 $($cases.Count) 件"
 $notes='ポートフォリオ保有・集中制限・クレジットVaR未接続。組み入れ推奨は未算出。'
 }
 'Pricing'{
 $vals=@($script:db.valuations|Where-Object {$_.fund_id -eq $c.fund_id -and (InPeriod $_.valuation_date $c)})
 $rows=@(foreach($g in ($vals|Group-Object valuation_date,fund_id,isin,base_currency)){
 $q=@($g.Group|Where-Object provider -eq 'QUANT');$base=$g.Group[0]
 foreach($provider in @('ICE','DIR')){$ext=@($g.Group|Where-Object provider -eq $provider);$pct=$null;$status='評価欠損／重複'
 if($q.Count -eq 1 -and $ext.Count -eq 1 -and (Num $q[0].market_value) -ne 0){$pct=100*((Num $ext[0].market_value)-(Num $q[0].market_value))/[math]::Abs((Num $q[0].market_value));$status=if([math]::Abs($pct) -ge $c.threshold){'閾値以上'}else{'範囲内'}}
 [pscustomobject]@{日付=$base.valuation_date;ISIN=$base.isin;通貨=$base.base_currency;評価会社=$provider;当社時価=$(if($q.Count -eq 1){$q[0].market_value}else{'—'});外部時価=$(if($ext.Count -eq 1){$ext[0].market_value}else{'—'});乖離率pct=$(if($null -ne $pct){[math]::Round($pct,4)}else{$null});判定=$status}
 }})
 $bad=@($rows|Where-Object 判定 -eq '閾値以上');$missing=@($rows|Where-Object 判定 -eq '評価欠損／重複')
 $summary="閾値以上乖離 $($bad.Count) 件 ／ 評価欠損等 $($missing.Count) 件"
 $notes="件数は日付×ISIN×評価会社×基準通貨の比較単位。閾値 $($c.threshold)% 。当社時価はQUANT入力値。"
 }
 'Execution'{
 $orders=@($script:db.orders|Where-Object {$_.fund_id -eq $c.fund_id -and (InPeriod $_.order_date $c)})
 $trades=@($script:db.trades|Where-Object {$_.fund_id -eq $c.fund_id -and (InPeriod $_.trade_date $c)})
 $rows=@(foreach($o in $orders){$fills=@($script:db.trades|Where-Object {$_.order_id -eq $o.order_id -and $_.fund_id -eq $o.fund_id -and (Day $_.trade_date) -le $c.hi});$qty=0.0;foreach($t in $fills){$qty+=Num $t.quantity};$remaining=[math]::Max(0,(Num $o.quantity)-$qty)
 [pscustomobject]@{発注ID=$o.order_id;ファンド=$o.fund_id;ISIN=$o.isin;業者=$o.broker;発注額面=$o.quantity;累計約定額面=$qty;未約定額面=$remaining;状態=$(if($qty -eq 0){'未約定'}elseif($qty -lt (Num $o.quantity)){'一部約定'}elseif($qty -gt (Num $o.quantity)){'超過約定・要確認'}else{'約定済み'})}})
 $unfilled=@($rows|Where-Object 未約定額面 -gt 0)
 $summary="発注 $($orders.Count) 件 ／ 期間内約定 $($trades.Count) 件 ／ 未完了 $($unfilled.Count) 件"
 $notes='期間内の発注を対象に終了日までの累計約定で残額判定。約定件数は期間内の全約定。取消状態の自動処理は未接続。'
 }
 'Sellside'{
 $trades=@($script:db.trades|Where-Object {$_.fund_id -eq $c.fund_id -and (InPeriod $_.trade_date $c)})
 $brokers=@(@($offers|ForEach-Object broker)+@($reports|ForEach-Object broker)+@($trades|ForEach-Object broker)|Sort-Object -Unique)
 $rows=@(foreach($b in $brokers){$rs=@($reports|Where-Object broker -eq $b);$os=@($offers|Where-Object broker -eq $b);$ts=@($trades|Where-Object broker -eq $b);$linked=0
 foreach($t in $ts){$issuer=@($script:db.offers|Where-Object isin -eq $t.isin|Select-Object -ExpandProperty issuer_id -Unique);if($issuer.Count -eq 1 -and @($script:db.reports|Where-Object {$_.broker -eq $b -and $_.issuer_id -eq $issuer[0] -and (Day $_.published_date) -le (Day $t.trade_date)}).Count){$linked++}}
 [pscustomobject]@{業者=$b;レポート件数=$rs.Count;オファー件数=$os.Count;約定件数=$ts.Count;関連レポート有約定=$linked;確認=$(if($ts.Count -gt $linked){'関連資料未記録・未照合'}elseif($rs.Count -and -not $ts.Count){'資料あり・商いなし'}else{'記録あり'})}
 })
 $check=@($rows|Where-Object 確認 -ne '記録あり');$summary="対象業者 $($rows.Count) 社 ／ 要確認 $($check.Count) 社"
 $notes='月次は期間に月初・月末を指定。レポートが商いを生んだという因果関係は判定しません。'
 }
 'MIS'{
 $inc=@($script:db.incidents|Where-Object {$_.fund_id -eq $c.fund_id -and (InPeriod $_.occurred_date $c)})
 $unresolved=@($inc|Where-Object status -ne '解決');$improve=@($inc|Where-Object {-not [string]::IsNullOrWhiteSpace($_.improvement)})
 $perf=@($script:db.performance|Where-Object {$_.fund_id -eq $c.fund_id -and (InPeriod $_.period_end $c)})
 $rows=@(foreach($i in $inc){[pscustomobject]@{区分='障害・改善';参照=$i.incident_id;状態=$i.status;概要=$i.summary;改善または指標=$i.improvement}}
 foreach($v in $perf){[pscustomobject]@{区分='パフォーマンス';参照="$($v.period_start) ～ $($v.period_end)";状態='入力TWR';概要="リターン $($v.twr_pct)% / benchmark $($v.benchmark_pct)%";改善または指標='入力値・再計算未接続'}}
 [pscustomobject]@{区分='コンプライアンス';参照=$c.fund_id;状態='未判定';概要='保有集中・取引時点規約・VaR';改善または指標='保有明細等の接続が必要'})
 $summary="未解決障害 $($unresolved.Count) 件 ／ 改善記録 $($improve.Count) 件 ／ 規約照合 未接続"
 $notes='障害は発生日が期間内の記録。期間前から継続する障害は対象外。改善記録は記載のある障害件数。'
 }
 }
 $meta="$($c.name) ／ $($c.lo.ToString('yyyy-MM-dd')) ～ $($c.hi.ToString('yyyy-MM-dd')) ／ 実行 $([datetime]::Now.ToString('yyyy-MM-dd HH:mm:ss'))"
 $file=RenderReport $key $rows $summary ($meta+' ／ '+$notes)
 $script:results[$key]=[pscustomobject]@{rows=@($rows);summary=$summary;meta=$meta;file=$file;notes=$notes;context=$c;fingerprint=(Fingerprint)}
 $ui["Result$key"].Text=$summary;$ui["Result$key"].Foreground=[Windows.Media.Brushes]::Teal;$ui["Meta$key"].Text='完了 ／ '+$meta;$ui["View$key"].IsEnabled=$true
 ShowResult $key;$ui.Status.Text=$notes
 }catch{
 $ui["Result$key"].Text='失敗 — '+$_.Exception.Message;$ui["Result$key"].Foreground=[Windows.Media.Brushes]::Firebrick;$ui["Meta$key"].Text='今回の結果はありません。再実行してください。'
 $script:results.Remove($key);if($script:active -eq $key){$script:active=$null;Bind DetailGrid @();$ui.OpenOutput.IsEnabled=$false;$ui.PrintPdf.IsEnabled=$false;$ui.CreateCase.IsEnabled=$false}
 }finally{$ui["Run$key"].IsEnabled=$true}
}
function MarkChanged {
 foreach($key in @($script:results.Keys)){$ui["Meta$key"].Text='条件変更あり・再実行してください ／ '+$script:results[$key].meta;$ui["Result$key"].Foreground=[Windows.Media.Brushes]::DarkGoldenrod}
}
function PrintResult {
 if(-not $script:active){return};$r=$script:results[$script:active]
 $doc=New-Object Windows.Documents.FlowDocument;$doc.FontFamily=New-Object Windows.Media.FontFamily 'Yu Gothic';$doc.FontSize=11;$doc.PagePadding=New-Object Windows.Thickness 40;$doc.ColumnWidth=1000
 foreach($text in @(('CURIE / '+$moduleNames[$script:active]),$r.meta,$r.summary,$r.notes,'架空データによる試作レポート')){$para=New-Object Windows.Documents.Paragraph;$para.Inlines.Add((New-Object Windows.Documents.Run ([string]$text)));$doc.Blocks.Add($para)}
 foreach($row in $r.rows){$line=@($row.PSObject.Properties|ForEach-Object {"$($_.Name): $($_.Value)"}) -join ' / ';$para=New-Object Windows.Documents.Paragraph;$para.Inlines.Add((New-Object Windows.Documents.Run $line));$doc.Blocks.Add($para)}
 $dialog=New-Object Windows.Controls.PrintDialog
 if($dialog.ShowDialog()){$doc.PageWidth=$dialog.PrintableAreaWidth;$doc.PageHeight=$dialog.PrintableAreaHeight;$paginator=([Windows.Documents.IDocumentPaginatorSource]$doc).DocumentPaginator;$dialog.PrintDocument($paginator,'CURIE '+$moduleNames[$script:active])}
}
LoadAll
$ui.Rating.ItemsSource=$ranks;$ui.Fund.ItemsSource=$script:db.funds;$ui.AnalysisFund.ItemsSource=$script:db.funds;$ui.Fund.SelectedIndex=0;$ui.AnalysisFund.SelectedIndex=0
$script:strategyPath=Join-Path $root 'data/strategy_notes.json'
if(Test-Path $script:strategyPath){$saved=Get-Content $script:strategyPath -Raw -Encoding UTF8|ConvertFrom-Json;foreach($prop in $saved.PSObject.Properties){$script:strategies[$prop.Name]=$prop.Value}}
$casePath=Join-Path $root 'output/cases.json';if(Test-Path $casePath){$script:cases=@(Get-Content $casePath -Raw -Encoding UTF8|ConvertFrom-Json)}
$ui.From.SelectedDate=[datetime]::Today.AddDays(1-[datetime]::Today.Day);$ui.To.SelectedDate=[datetime]::Today
$ui.FolderPath.Text='配置先：'+(Join-Path $root 'data')
$ui.Fund.Add_SelectionChanged({Guard{LoadFund}})
$ui.SaveFund.Add_Click({Guard{
 $r=GetRules;$fx=Num $ui.FXLimit.Text;if($fx -lt 0 -or $fx -gt 100){throw '外貨比率は0〜100%です。'}
 if($ui.VaRLimit.Text -ne ''){$v=Num $ui.VaRLimit.Text;if($v -lt 0 -or $v -gt 100){throw 'VaR上限は0〜100%です。'}}
 $f=@($script:db.funds|Where-Object fund_id -eq $r.fund_id)[0];$f.currencies=$r.currencies -join ';';$f.min_years=$ui.MinY.Text;$f.max_years=$ui.MaxY.Text;$f.min_rating=[string]$ui.Rating.SelectedItem;$f.min_spread_bp=$ui.Spread.Text;$f.max_order_amount=$ui.Limit.Text
 $script:db.funds|Export-Csv (Join-Path $root 'data/funds.csv') -NoTypeInformation -Encoding UTF8
 $script:strategies[$f.fund_id]=[pscustomobject]@{purpose=$ui.Purpose.Text;fx_limit_pct=$ui.FXLimit.Text;credit_var_limit_pct=$ui.VaRLimit.Text}
 $script:strategies|ConvertTo-Json -Depth 5|Set-Content $script:strategyPath -Encoding UTF8
 MarkChanged;$ui.Status.Text='ファンド戦略を保存しました。VaR・外貨保有比率の計算は未接続です。'
}})
foreach($key in $moduleNames.Keys){
 $ui["Run$key"].Tag=$key;$ui["Run$key"].Add_Click({param($sender,$eventArgs) RunAnalysis ([string]$sender.Tag)})
 $ui["View$key"].Tag=$key;$ui["View$key"].Add_Click({param($sender,$eventArgs) ShowResult ([string]$sender.Tag)})
}
$ui.From.Add_SelectedDateChanged({MarkChanged});$ui.To.Add_SelectedDateChanged({MarkChanged});$ui.AnalysisFund.Add_SelectionChanged({MarkChanged});$ui.Threshold.Add_TextChanged({MarkChanged})
$ui.Today.Add_Click({$ui.From.SelectedDate=[datetime]::Today;$ui.To.SelectedDate=[datetime]::Today})
$ui.OpenOutput.Add_Click({Guard{if($script:active){Start-Process -FilePath $script:results[$script:active].file}}})
$ui.PrintPdf.Add_Click({Guard{PrintResult}})
$ui.CreateCase.Add_Click({Guard{
 if($script:active -ne 'Proposal'){throw '適合候補の明細から選んでください。'}
 if((Fingerprint) -ne $script:results.Proposal.fingerprint){throw 'データが更新されています。再実行してください。'}
 $ctx=Context;$last=$script:results.Proposal.context
 if($ctx.fund_id -ne $last.fund_id -or $ctx.lo -ne $last.lo -or $ctx.hi -ne $last.hi){throw '対象条件を変更しています。再実行してください。'}
 $o=$ui.DetailGrid.SelectedItem;if($null -eq $o){throw '候補を選んでください。'}
 $f=@($script:db.funds|Where-Object fund_id -eq $o.fund_id)[0];$qty=Num $ui.Quantity.Text
 if($qty -le 0 -or $qty -gt (Num $f.max_order_amount)){throw '額面は正数かつ案件上限以下です。'}
 $script:cases+=[pscustomobject]@{case_id=[guid]::NewGuid().ToString();created_at=[datetime]::Now.ToString('o');fund_id=$o.fund_id;isin=$o.isin;broker=$o.broker;side='BUY';quantity=$qty;currency=$o.currency;reference_price=$o.price;status='DRAFT';send_to_market=$false;strategy_snapshot=($f|Select-Object *)}
 ConvertTo-Json -InputObject @($script:cases) -Depth 8|Set-Content $casePath -Encoding UTF8
 $ui.ResultProposal.Text="条件適合候補 $($script:results.Proposal.rows.Count) 件 ／ 発注案件 $(@($script:cases|Where-Object {$_.fund_id -eq $ctx.fund_id -and (InPeriod ([datetime]$_.created_at).ToString('yyyy-MM-dd') $ctx)}).Count) 件"
 $ui.Status.Text='発注案件を保存しました。アラジン送信・市場発注は行っていません。'
}})
$ui.ExportCases.Add_Click({Guard{
 if(-not $script:cases.Count){throw '発注案件はありません。'};$path=SaveDialog 'JSON (*.json)|*.json' 'curie_aladdin_cases.json'
 if($path){[ordered]@{purpose='ORDER_CASE_ONLY';integration_status='UNMAPPED_NOT_SENT';cases=@($script:cases)}|ConvertTo-Json -Depth 10|Set-Content -LiteralPath $path -Encoding UTF8;$ui.Status.Text='独自形式の案件JSONを出力。アラジンAPIは未接続。'}
}})
LoadFund;Monitor
$timer=New-Object Windows.Threading.DispatcherTimer;$timer.Interval=[timespan]::FromSeconds(5);$timer.Add_Tick({try{Monitor}catch{$ui.Status.Text='配置データ確認中: '+$_.Exception.Message}});$timer.Start()
$window.Add_Closed({$timer.Stop()})
[void]$window.ShowDialog()
